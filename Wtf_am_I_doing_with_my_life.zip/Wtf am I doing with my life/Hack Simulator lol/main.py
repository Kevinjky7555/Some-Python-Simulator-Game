class Hack:
	"""
	
	<<Hack List>>
	
	1 = Discord
	2 = PlayStore
	3 = ERROR REPAIRER
	
	
"""

data = open('Texts/list.txt', 'r')
print(data.read())

def __init__(self, hack):
	self.hack = hack
	self.id = id
	
hack = input()
id = input()
	
if hack  == '1':
	data = open('Texts/discord.py', 'r')
	print(data.read())

elif hack == '2':
	data = open('Texts/bs.txt', 'r')
	print(data.read())
		
if hack == '3':
	data = open('Texts/shit.py', 'r')
	print(data.read())
	
elif hack  == '4':
	data = open('Texts/server.py', 'r')
	print(data.read())


hack = input()
id == input()
	
if hack  == '1':
	data = open('Texts/discord.py', 'r')
	print(data.read())

elif hack == '2':
	data = open('Texts/bs.txt', 'r')
	print(data.read())
	
if hack == '3':
	data = open('Texts/shit.py', 'r')
	print(data.read())
	
elif hack  == '4':
	data = open('Texts/server.py', 'r')
	print(data.read())
		