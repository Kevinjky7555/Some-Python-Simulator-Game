[INFO] Hacking Discord Server ".."...


[INFO] Error, no connection.

Using emergency Wi-Fis... searching for an access point...


[INFO] Access point found.

[EMERGENCY]:

-911, what's your fucking emergency?

[INFO] Don't try to escape from the call, you will get loads of shit...

Tell them the following:

1. Your full name
2. The following text:

"I ate a lot of shit and I want to hack a Discord Server plz"


[EMERGENCY]:

-911, WHAT'S YOUR FUCKING EMERGENCY?

[YOU]:

-Sir, I ate shit... can you now plz hack a Discord Server for me... plzzz

[EMERGENCY]:

-no

-- CALL ENDED --

bruh, big fail