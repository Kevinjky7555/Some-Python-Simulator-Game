Hack... MY SHIT!

[INFO] You took the shit and ate it


bruh, shitty ending